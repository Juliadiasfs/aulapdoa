<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Geral</title>
</head>
<body>
    <h1>Cadastro de Carro</h1>
        <form action="model/carro/inserircarro.php" method="POST">
         Carro:<br/>
         <input type="text" name="cxcarro"/></br>
         Fabricante:<br/>
         <input type="text" name="cxfabricante"/></br>
         Valor:<br/>
         <input type="text" name="cxvalor"/></br>
         Ano:<br/>
         <input type="text" name="cxano"/></br>
         <input type="submit" value="Gravar"/></br>
    </form>
</body>
</html>